# 电子证书查询系统部署指南

## 系统概述

电子证书查询系统是一个纯前端Web应用，使用HTML、CSS和JavaScript开发，数据存储在浏览器的localStorage中。系统包含两个主要部分：

1. **前台查询系统** (`index.html`) - 供用户查询和验证证书
2. **后台管理系统** (`admin/dashboard.html`) - 供管理员管理证书数据

## 部署方案

由于本系统是纯前端应用，部署非常简单，可以选择以下几种方式：

### 方案一：本地部署（开发测试）

1. **直接打开HTML文件**
   - 找到 `index.html` 文件
   - 双击打开或右键选择浏览器打开
   - 系统将在本地浏览器中运行

2. **使用本地服务器（推荐）**
   - 安装Node.js（如果尚未安装）
   - 使用Python内置服务器：
     ```bash
     cd certificate-system
     python -m http.server 8000
     ```
   - 或使用Node.js的http-server：
     ```bash
     npm install -g http-server
     cd certificate-system
     http-server -p 8000
     ```
   - 在浏览器中访问：`http://localhost:8000`

### 方案二：Web服务器部署（生产环境）

#### Nginx部署

1. **安装Nginx**
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install nginx
   
   # CentOS/RHEL
   sudo yum install nginx
   # 或
   sudo dnf install nginx
   ```

2. **复制项目文件**
   ```bash
   sudo cp -r certificate-system /var/www/html/
   sudo chown -R www-data:www-data /var/www/html/certificate-system
   ```

3. **配置Nginx**
   ```bash
   sudo nano /etc/nginx/sites-available/certificate-system
   ```

   粘贴以下配置：
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;
       
       root /var/www/html/certificate-system;
       index index.html;
       
       location / {
           try_files $uri $uri/ =404;
       }
       
       # 可选：启用HTTPS
       # listen 443 ssl;
       # ssl_certificate /path/to/ssl/cert.pem;
       # ssl_certificate_key /path/to/ssl/private.key;
   }
   ```

4. **启用站点并重启Nginx**
   ```bash
   sudo ln -s /etc/nginx/sites-available/certificate-system /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

5. **访问系统**
   - 前台：`http://your-domain.com`
   - 后台：`http://your-domain.com/admin/login.html`

#### Apache部署

1. **安装Apache**
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install apache2
   
   # CentOS/RHEL
   sudo yum install httpd
   # 或
   sudo dnf install httpd
   ```

2. **复制项目文件**
   ```bash
   sudo cp -r certificate-system /var/www/html/
   sudo chown -R www-data:www-data /var/www/html/certificate-system  # Debian/Ubuntu
   # 或
   sudo chown -R apache:apache /var/www/html/certificate-system  # CentOS/RHEL
   ```

3. **配置Apache虚拟主机**
   ```bash
   sudo nano /etc/apache2/sites-available/certificate-system.conf  # Debian/Ubuntu
   # 或
   sudo nano /etc/httpd/conf.d/certificate-system.conf  # CentOS/RHEL
   ```

   粘贴以下配置：
   ```apache
   <VirtualHost *:80>
       ServerName your-domain.com
       DocumentRoot /var/www/html/certificate-system
       
       <Directory /var/www/html/certificate-system>
           Options Indexes FollowSymLinks
           AllowOverride All
           Require all granted
       </Directory>
       
       ErrorLog ${APACHE_LOG_DIR}/certificate-system_error.log
       CustomLog ${APACHE_LOG_DIR}/certificate-system_access.log combined
   </VirtualHost>
   ```

4. **启用站点并重启Apache**
   ```bash
   # Debian/Ubuntu
   sudo a2ensite certificate-system.conf
   sudo systemctl restart apache2
   
   # CentOS/RHEL
   sudo systemctl restart httpd
   ```

5. **访问系统**
   - 前台：`http://your-domain.com`
   - 后台：`http://your-domain.com/admin/login.html`

### 方案三：云平台部署

#### GitHub Pages

1. **创建GitHub仓库**
   - 在GitHub上创建一个新的仓库
   - 将项目文件上传到仓库

2. **启用GitHub Pages**
   - 进入仓库设置
   - 找到"Pages"选项
   - 选择分支（通常是main或master）
   - 点击"Save"
   - 几分钟后，系统将提供访问URL

#### Netlify

1. **创建Netlify账户**
   - 访问 [Netlify官网](https://www.netlify.com/)
   - 注册并登录

2. **部署项目**
   - 点击"New site from Git"
   - 连接GitHub/GitLab/Bitbucket仓库
   - 选择项目仓库
   - 点击"Deploy site"
   - 部署完成后，Netlify将提供访问URL

#### Vercel

1. **创建Vercel账户**
   - 访问 [Vercel官网](https://vercel.com/)
   - 注册并登录

2. **部署项目**
   - 点击"New Project"
   - 连接GitHub/GitLab/Bitbucket仓库
   - 选择项目仓库
   - 点击"Deploy"
   - 部署完成后，Vercel将提供访问URL

## 数据存储说明

本系统使用浏览器的localStorage进行数据存储，具有以下特点：

- **数据存储位置**：用户浏览器本地
- **存储限制**：通常为5-10MB
- **数据隔离**：不同浏览器/设备之间数据不共享
- **隐私安全**：数据仅存储在用户本地，不会上传到服务器

### 数据持久化方案

如果需要更可靠的数据存储，可以考虑以下方案：

1. **升级为前后端分离架构**
   - 后端使用Node.js/Express、Python/Flask等
   - 数据库使用MySQL、PostgreSQL或MongoDB
   - API接口替代localStorage操作

2. **使用IndexedDB**
   - 浏览器内置的NoSQL数据库
   - 存储容量更大（通常为50MB以上）
   - 支持更复杂的数据结构

3. **使用云存储服务**
   - Firebase Realtime Database
   - Supabase
   - 其他BaaS（Backend as a Service）平台

## 安全建议

1. **后台访问控制**
   - 更改默认管理员密码
   - 考虑添加IP限制或其他访问控制机制

2. **数据验证**
   - 前端表单验证已实现
   - 如需更高级别的安全，建议实现后端验证

3. **HTTPS加密**
   - 在生产环境中启用HTTPS
   - 配置SSL证书

4. **定期备份**
   - 定期导出证书数据备份
   - 使用批量导出功能保存Excel文件

## 系统更新

1. **更新步骤**
   - 备份现有数据（使用后台批量导出功能）
   - 替换项目文件
   - 导入备份数据（如需要）

2. **版本控制**
   - 建议使用Git进行版本控制
   - 记录每次更新的内容和变更

## 常见问题排查

1. **页面无法访问**
   - 检查服务器状态
   - 验证文件权限
   - 查看Web服务器错误日志

2. **数据丢失**
   - 检查浏览器localStorage是否被清除
   - 验证浏览器隐私设置
   - 确认是否使用了隐私浏览模式

3. **功能异常**
   - 清除浏览器缓存
   - 检查浏览器控制台错误信息
   - 验证浏览器兼容性（推荐使用Chrome、Firefox、Edge等现代浏览器）

## 浏览器兼容性

本系统支持所有现代浏览器：
- Chrome (推荐)
- Firefox
- Safari
- Edge
- IE 11 (部分功能可能受限)

## 性能优化建议

1. **图片优化**
   - 压缩证书模板图片
   - 使用适当的图片格式（WebP、JPEG、PNG）

2. **代码优化**
   - 合并和压缩CSS/JavaScript文件
   - 移除未使用的代码

3. **加载优化**
   - 使用CDN加速静态资源
   - 实现懒加载

## 扩展功能建议

1. **多语言支持**
2. **深色模式**
3. **证书批量打印**
4. **移动端适配优化**
5. **更丰富的证书模板**

---

如有任何部署问题，请参考上述指南或联系技术支持。